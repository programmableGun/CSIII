public class MyTester
{
	public static void main(String[] args)
	{
		//Write your tests here
	}
}
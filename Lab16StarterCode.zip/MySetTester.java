public class MySetTester
{
	public static void main(String[] args)
	{
		//Write code here to test your MySet class
	}
}
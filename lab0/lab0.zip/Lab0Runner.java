//name:Benjamin Santos

public class Lab0Runner {


    public static void main(String[] args)
    {
        Lab0 lab = new Lab0();
        lab.display (1, 100);
    }

    
}